﻿namespace Flsurf.Domain.Freelance.Enums
{
    public enum WorkSessionStatus
    {
        Pending, 
        Approved,
        Rejected 
    }
}
