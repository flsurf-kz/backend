﻿namespace Flsurf.Domain.Freelance.Enums
{
    public enum Countries
    {
        Kazakhstan, 
        Russia, 
        Belarus, 
    }
}
