﻿namespace Flsurf.Domain.Freelance.Enums
{
    public enum BudgetType
    {
        Hourly, 
        Fixed, 
    }
}
