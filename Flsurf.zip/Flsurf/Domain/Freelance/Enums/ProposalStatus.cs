﻿namespace Flsurf.Domain.Freelance.Enums
{
    public enum ProposalStatus
    {
        Pending,
        Accepted, 
        Hidden, 
    }
}
