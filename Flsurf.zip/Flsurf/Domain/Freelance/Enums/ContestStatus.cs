﻿namespace Flsurf.Domain.Freelance.Enums
{
    public class ContestStatus
    {
    }
}
