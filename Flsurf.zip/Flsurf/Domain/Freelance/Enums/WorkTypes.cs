﻿namespace Flsurf.Domain.Freelance.Enums
{
    public class WorkTypes
    {
    }
}
