﻿namespace Flsurf.Domain.Freelance.Enums
{
    public enum JobLevel
    {
        Beginner, 
        Intermediate, 
        Expert, 
    }
}
