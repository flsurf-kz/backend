﻿namespace Flsurf.Domain.Freelance.Enums
{
    public enum DurationTypes
    {
        LessOneMonth, 
        OneToMonth, 
        ThreeToSixthMonth, 
        MoreSixthMonth, 
    }
}
