﻿namespace Flsurf.Domain.Freelance.Enums
{
    public enum AvailabilityStatus
    {
        Open,      // Открыт к работе
        Busy,      // Занят
        Vacation   // В отпуске
    }

}
