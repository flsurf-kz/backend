﻿namespace Flsurf.Domain.Freelance.Enums
{
    public enum WorkSnapshotStatus
    {
        Pause, 
        SessionCompleted, 
        SessionStarted, 
        Resume, 
    }
}
