﻿namespace Flsurf.Domain.Freelance.Enums
{
    public enum TeamInvitationStatus
    {
        Rejected, 
        Accepted, 
        Waiting
    }
}
