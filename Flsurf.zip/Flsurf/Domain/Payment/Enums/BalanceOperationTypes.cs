﻿namespace Flsurf.Domain.Payment.Enums
{
    // admin only!! 
    public enum BalanceOperationType
    {
        Freeze,
        Unfreeze,
        PendingIncome, 
        Deposit, 
        Withdrawl
    }
}
