﻿namespace Flsurf.Domain.Payment.Enums
{
    public enum WalletBlockReason
    {
        None,
        FraudSuspicion,
        LegalIssue,
        UserRequest
    }
}
