﻿namespace Flsurf.Domain.Messanging.Enums
{
    public enum ChatTypes
    {
        Group, 
        Direct, 
        Support
    }
}
