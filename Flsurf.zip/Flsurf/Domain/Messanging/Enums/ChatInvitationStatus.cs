﻿namespace Flsurf.Domain.Messanging.Enums
{
    public enum ChatInvitationStatus
    {
        Rejected, 
        Accepted, 
        Waiting
    }
}
