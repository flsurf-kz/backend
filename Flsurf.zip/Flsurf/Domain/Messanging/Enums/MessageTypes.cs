﻿namespace Flsurf.Domain.Messanging.Enums
{
    public class MessageTypes
    {
    }
}
