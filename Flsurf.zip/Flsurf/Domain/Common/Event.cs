﻿using Flsurf.Infrastructure.EventDispatcher;

namespace Flsurf.Domain.Common
{
    public abstract class DomainEvent : BaseEvent
    {
    }
}
