﻿namespace Flsurf.Domain.Staff.Enums
{
    public enum TicketStatus
    {
        Open,
        Closed,
        InProgress
    }
}
