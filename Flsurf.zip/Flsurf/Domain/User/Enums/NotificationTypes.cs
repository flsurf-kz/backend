﻿namespace Flsurf.Domain.User.Enums
{
    public enum NotificationTypes
    {
        System, 
        Payment,
        Other
    }
}
