﻿namespace Flsurf.Domain.User.Enums
{
    public enum UserTypes
    {
        Freelancer, 
        Client, 
        NonUser, 
    }
}
