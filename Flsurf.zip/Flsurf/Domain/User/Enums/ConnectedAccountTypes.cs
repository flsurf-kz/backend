﻿namespace Flsurf.Domain.User.Enums
{
    public enum ConnectedAccountTypes
    {
        Github,
        HeadHunter,
        LinkedIn
    }
}
