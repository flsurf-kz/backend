﻿namespace Flsurf.Domain.User.Enums
{
    public enum UserRoles
    {
        User, 
        Moderator, 
        Admin, 
        Superadmin 
    }
}
