﻿namespace Flsurf.Application.Freelance.Interfaces
{
    // Job + Bookmarks
    public interface IJobService
    {
    }
}
