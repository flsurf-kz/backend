﻿namespace Flsurf.Application.Freelance.Interfaces
{
    // Freelancer group + freelancer profile + portfolio projects 
    public interface IFreelancerService
    {
    }
}
