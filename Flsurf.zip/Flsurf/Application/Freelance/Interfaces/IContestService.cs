﻿namespace Flsurf.Application.Freelance.Interfaces
{
    public interface IContestService
    {
    }
}
