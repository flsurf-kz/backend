﻿namespace Flsurf.Application.Freelance.Interfaces
{
    public interface ISkillService
    {
    }
}
