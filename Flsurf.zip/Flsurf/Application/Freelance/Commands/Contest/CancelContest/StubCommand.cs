﻿using Flsurf.Application.Common.cqrs;

namespace Flsurf.Application.Freelance.Commands.Category.UpdateCategory
{
    public class CreateFreelancerTeamCommand : BaseCommand
    {
        public Guid Id { get; }
    }
}
