﻿namespace Flsurf.Application.Freelance.Commands.Job
{
    // Signs contract and closes job, more of job than contract responsiblity 
    public class SignContract
    {
    }
}
