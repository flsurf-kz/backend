﻿namespace Flsurf.Application.Freelance.Commands.Contract
{
    public class UpdateContract
    {
    }
}
