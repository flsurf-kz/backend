﻿namespace Flsurf.Application.Freelance.Permissions
{
    public class ZedContest
    {
    }
}
