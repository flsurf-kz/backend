﻿namespace Flsurf.Application.Freelance.Permissions
{
    public class ZedPortfolioProject
    {
    }
}
