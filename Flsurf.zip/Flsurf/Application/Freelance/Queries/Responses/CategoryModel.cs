﻿namespace Flsurf.Application.Freelance.Queries.Responses
{
    public class CategoryModel
    {
    }
}
