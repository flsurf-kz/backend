﻿namespace Flsurf.Application.Freelance.Queries.Responses
{
    public class SkillModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}
