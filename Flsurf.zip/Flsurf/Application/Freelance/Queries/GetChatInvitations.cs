﻿namespace Flsurf.Application.Freelance.Queries
{
    public class GetChatInvitations
    {
    }
}
