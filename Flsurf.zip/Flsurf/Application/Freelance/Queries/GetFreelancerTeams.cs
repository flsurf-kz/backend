﻿namespace Flsurf.Application.Freelance.Queries
{
    public class GetFreelancerTeams
    {
    }
}
