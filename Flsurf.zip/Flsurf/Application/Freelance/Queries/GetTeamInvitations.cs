﻿namespace Flsurf.Application.Freelance.Queries
{
    public class GetTeamInvitations
    {
    }
}
