﻿namespace Flsurf.Application.Freelance.Services
{
    public class ContestService
    {
    }
}
