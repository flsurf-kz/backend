﻿namespace Flsurf.Application.Messaging.UseCases
{
    public class InspectChat
    {
    }
}
